/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.arbcbs.elFlagger;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;

import org.apache.log4j.Logger;

public class FileSystemWatchSG {

	static Logger logger = Logger.getLogger(FileSystemWatchSG.class);
	
   private static FileSystemWatchSG instance = null;
   private FileSystemWatchSG() {
      // Exists only to defeat instantiation.
   }

   public static FileSystemWatchSG getInstance() {
      if(instance == null) {
    	  System.out.println("Creating New Instance");
    	  logger.info("Creating New Instance");
         instance = new FileSystemWatchSG();
      }
      else {
    	  logger.info("Re-Use Instance");
      }
      return instance;
   }
   

   protected static void demoMethod( ) {
	   logger.info("demoMethod for singleton");
   }
   
   protected WatchService startFileSystemWatcher()throws IOException, InterruptedException {
	   WatchService watchService = FileSystems.getDefault().newWatchService();
       Path path = Paths.get("C:\\Users\\cwtillar\\Desktop");
       path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_DELETE, StandardWatchEventKinds.ENTRY_MODIFY);
       WatchKey key;
       /*while ((key = watchService.take()) != null) {
           for (WatchEvent<?> event : key.pollEvents()) {
               System.out.println("Event kind:" + event.kind() + ". File affected: " + event.context() + ".");
               //shutdown();
           }
           key.reset();
       }
*/
       //watchService.close();
       return watchService;
   }
   
   protected void shutdown()throws IOException, InterruptedException {
		 final WatchService watchService1 = FileSystems.getDefault().newWatchService();   
		 logger.info("Shutdown command recieved");
	        Runtime.getRuntime().addShutdownHook(new Thread() {
                    @Override
	            public void run() {
	                try {
	                    watchService1.close();
	                    logger.info("Shutdown complete");
	                } catch (IOException e) {
	                    logger.info("Shutdown complete"+e);
	                }
	            }
	        });

	        WatchKey key1 = null;
	        while (true) {
	        	System.out.println("Shutdown complete");
	            key1 = watchService1.take(); //throws ClosedWatchServiceException
	            //execution
	        }
	}	    
}