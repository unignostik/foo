/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.arbcbs.elFlagger;

import java.io.IOException;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.log4j.Logger;

/**
 *
 * @author cwtillar
 */

public class Main{
    
    Logger logger = Logger.getLogger(Main.class);

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        java.lang.System.setProperty("jdk.tls.client.protocols", "TLSv1,TLSv1.1,TLSv1.2");
        
        ExcessLossFlagger elf = new ExcessLossFlagger(); //create flagger instance
        FileSystemWatchSG fileSystemWatchSC = FileSystemWatchSG.getInstance(); //create watch instance
        
        //set db login vars
        String dbUSER = "ABCBSNET\\bpmadmin";
        String dbPASS = "G5y#eLhq1";
        String dbHOST = "10.1.76.100:1433";        
        
        System.out.println("Successfully started Main.main...");
        
        WatchService watchService;
	try {
            System.out.println("Successfully started try...");
		watchService = fileSystemWatchSC.startFileSystemWatcher();
		 WatchKey key;
	      while ((key = watchService.take()) != null) { //start watch
	          for (WatchEvent<?> event : key.pollEvents()) {
                      
                        System.out.println("Event kind:" + event.kind() + ". File affected: " + event.context() + "."); //print event that occurred
                        String folderName = event.context().toString().trim(); //folder that was changed
                      
                        //folder has been created. Get its company key and flip the flag in the database for the company to 'Y'
                        if (event.kind() == StandardWatchEventKinds.ENTRY_CREATE) {
                            Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher((CharSequence) folderName); //get text between (), which is company key
                            //flip flag
                            while(m.find()){
                                String companyKey = m.group(1); //company key
                                String query = "update [BPMD].[dbo].[company] set el_reporting='Y' where company_name like '%"+companyKey+")'";
                                elf.queryDB(dbUSER, dbPASS, dbHOST, query);
                            }
                        }
                        //folder has been deleted. Get its company key and flip the flag in the database for the company to 'N'
                        else if (event.kind() == StandardWatchEventKinds.ENTRY_DELETE) {
                            Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher((CharSequence) folderName); //get text between (), which is company key
                            //flip flag
                            while(m.find()){
                                String companyKey = m.group(1); //company key
                                String query = "update [BPMD].[dbo].[company] set el_reporting='N' where company_name like '%"+companyKey+")'";
                                elf.queryDB(dbUSER, dbPASS, dbHOST, query);
                            }
                        }
	                if ("STOP".equalsIgnoreCase(folderName)) {
	            	  System.out.println("Folder Matched for ShutDown");
	            	  fileSystemWatchSC.shutdown();
	                }
	              //shutdown();
	            }
	          key.reset();
	      }
	} catch (IOException | InterruptedException e) {
            System.out.println("Catch statement executed..\n");
            System.out.println("ERROR ---> "+e);
	}  
    }
}
