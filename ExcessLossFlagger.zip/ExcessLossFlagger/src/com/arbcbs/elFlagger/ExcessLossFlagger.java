/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.arbcbs.elFlagger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/*
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
*/
import java.util.logging.Level;
import java.util.logging.Logger;
/*
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
*/

/**
 *
 * @author cwtillar
 */
public class ExcessLossFlagger {
    

    
    private String dbUSER;
    private String dbPASS;
    private String dbHOST;
    
    /*
    private String svrUSER;
    private String svrPASS;
    private String svrHOST;
    private int svrPORT;
    */
    
    private String companyKey;
    
    /**
     * @param args the command line arguments
    */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args){
   }    
    
    //method to execute a query on db table
    public void queryDB(String username, String password, String host, String query){
        
        //attempt database connection, return null if unsucessful
        try {
            DriverManager.registerDriver(new com.microsoft.sqlserver.jdbc.SQLServerDriver());
            String dbURL = "jdbc:sqlserver://"+host+";user="+username+";password="+password+";integratedSecurity=true;";
            Connection conn = DriverManager.getConnection(dbURL);
            //set and execute query 
            try (Statement st = conn.createStatement()) {
                int rs = st.executeUpdate(query);
                System.out.println("Sucess with return value "+rs);
            } catch (SQLException ex) {
                System.out.println("Error ---> "+ ex);
                Logger.getLogger(ExcessLossFlagger.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ExcessLossFlagger.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //method to run commands on server via ssh
    /*
    public List executeCommand (String command, String user, String pass, String host, int port){
     List<String> result = new ArrayList<>();
     
     try{

         JSch jsch = new JSch();
 
         
         * Open a new session, with your username, host and port
         * Set the password and call connect.
         * session.connect() opens a new connection to remote SSH server.
         * Once the connection is established, you can initiate a new channel.
         * this channel is needed to connect to remotely execution program
         
         Session session = jsch.getSession(user, host, port);
         session.setConfig("StrictHostKeyChecking", "no");
         session.setPassword(pass);
         session.connect();
 
         //create the excution channel over the session
         ChannelExec channelExec = (ChannelExec)session.openChannel("exec");
 
         // Gets an InputStream for this channel. All data arriving in as messages from the remote side can be read from this stream.
         InputStream in = channelExec.getInputStream();
 
         // Set the command that you want to execute
         // In our case its the remote shell script
         channelExec.setCommand(command);
 
         // Execute the command
         channelExec.connect();
 
         // Read the output from the input stream we set above
         BufferedReader reader = new BufferedReader(new InputStreamReader(in));
         String line;
         
         //Read each line from the buffered reader and add it to result list
         // You can also simple print the result here 
         while ((line = reader.readLine()) != null)
         {
             result.add(line);
         }
         //System.out.println("SSH Result Set--->"+result.toString());
         //retrieve the exit status of the remote command corresponding to this channel
         int exitStatus = channelExec.getExitStatus();
 
         //Safely disconnect channel and disconnect session. If not done then it may cause resource leak
         channelExec.disconnect();
         session.disconnect();
 
         if(exitStatus < 0){
             System.out.println("Done, but exit status not set!");
         }
         else if(exitStatus > 0){
             System.out.println("Done, but with error!");
         }
         else{
             System.out.println("Done!");
         }
     }
     catch(JSchException | IOException e){
         System.err.println("Error: " + e);
     }
     //System.out.println(result);
     return results;  
    }
    */
    
    //method to flip el_reporting flag in company table
    /*
    public void checkToFlip(String svrUSR, String svrPASS, String svrHOST, int svrPORT, String dbUSR, String dbPASS, String dbHOST, String companyKey){
        
        //set db login vars
        dbUSR = "ABCBSNET\\bpmadmin";
        dbPASS = "G5y#eLhq1";
        dbHOST = "10.1.76.100:1433";        
        
        //set ssh login vars
        svrUSR = "bpmadmin";
        svrPASS = "G5y#eLhq1";
        svrHOST = "cwy1cogprd1.abcbs.net"; //10.0.145.42
        svrPORT = 22;
        
        ExcessLossFlagger elf = new ExcessLossFlagger(); //create ExcessLossFlagger instance
       
        List<String> rs = elf.executeCommand("cd ..; cd ..; cd cog/output/excessLoss/Reports; ls", svrUSER, svrPASS, svrHOST, svrPORT); //ssh to get company dirs
        
        //iterate through results
        Iterator it = rs.iterator();
        while(it.hasNext()){
            Matcher m = Pattern.compile("\\(([^)]+)\\)").matcher((CharSequence) it.next()); //remove all but numerics
            while(m.find()){
                if (m.group(1).equals(companyKey)){ //provided value matches value in results; flip flag
                    System.out.println("Company found... flipping flag\n");
                    //set and execute query to update 'el_reporting' flag to 'Y' for given company
                    String query = "update [BPMD].[dbo].[company] set el_reporting='Y' where company_name='%"+companyKey+"%'";
                    elf.queryDB(dbUSER, dbPASS, dbHOST, query);
                } else{
                    System.out.println("No EL for company, exiting...\n");
                }
            } 
        }
    }
    */
}
