//
//  ViewController.swift
//  Note Taker
//
//  Created by Chase Tillar on 1/11/19.
//  Copyright © 2019 Chase Tillar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //outlets
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet weak var backToLectures: UIBarButtonItem!
    
    //vars
    var lectureName = String()
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //recordButton button is pressed
    @IBAction func recordPressed(_ sender: Any) {
        
        //start recording speach to text
        
    }
    
    //doneButton is pressed
    @IBAction func donePressed(_ sender: Any) {
        
        //create ui alert
        let alert = UIAlertController(title: "Enter a name for your new recording", message: "", preferredStyle: .alert)
            //add text field to alert
        alert.addTextField { (UITextField) in
            UITextField.placeholder = "Enter lecture name..."
        }
        
        //add "Confirm" option
        alert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: { [weak alert] (_) in
                //when pressed, add user input to var
                let text = alert?.textFields![0]
                self.lectureName = (text?.text)!
        }))
        //present alert
        self.present(alert, animated: true, completion: nil)
        
    }
    
    
    @IBAction func backToLecturesPressed(_ sender: Any) {
        
    }
    
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination
        if let destination = segue.destination as? TableViewController {
            destination.lectures.append(lectureName)
            print(destination.lectures)
        }
        // Pass the selected object to the new view controller.
    }
    
}
