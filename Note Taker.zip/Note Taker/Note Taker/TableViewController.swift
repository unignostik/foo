//
//  TableViewController.swift
//  Note Taker
//
//  Created by Chase Tillar on 1/3/19.
//  Copyright © 2019 Chase Tillar. All rights reserved.
//

import UIKit

//declare defaults for app
let defaults = UserDefaults(suiteName: "com.ct.Light-Lecture")

class TableViewController: UITableViewController {
    
    //outlets
    @IBOutlet weak var addRowButton: UIBarButtonItem!
    
    //variable to hold lecture names, for population of table view
    var lectures = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()

        //preserve selection between presentations
        self.clearsSelectionOnViewWillAppear = false
        //load in saved lectures
        //getLectures()
        self.tableView.reloadData()
       
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        tableView.reloadData()
    }

    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lectures.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "lectures", for: indexPath)

        cell.textLabel?.text = lectures[indexPath.row]
        return cell
    }
    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            lectures.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.reloadData()
            saveLectuers(lectures: lectures)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    @IBAction func addTableItem(_ sender: Any) {
        
        //create ui alert
        let alert = UIAlertController(title: "Enter a name for your new recording", message: "", preferredStyle: .alert)
        //add text field to alert
        alert.addTextField { (UITextField) in
            UITextField.placeholder = "Enter lecture name..."
        }
        //add "Confirm" option
        alert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: { [weak alert] (_) in
            //when pressed, add user input to var
            let text = alert?.textFields![0]
            self.lectures.append((text?.text)!)
            self.tableView.reloadData()
        }))
        //present alert
        self.present(alert, animated: true, completion: nil)
        
    }
    
    //save lecture array to device
    func saveLectuers(lectures: [String]) {
        defaults?.set(lectures, forKey: "LectureArray")
        defaults?.synchronize()
    }
    
    //pull saved lectures from devics
    func getLectures() {
        let data = defaults?.value(forKey: "LectureArray")
        if data != nil {
            lectures = data as! [String]
        }
    }
    

}
